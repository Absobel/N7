#include <stdlib.h>
int main(){
    int valeur = 10, produit = 23; // déclaration et initialisation de deux entiers, 
    double numerateur = 10.3;
    char initiale = 'A'; 

    produit = produit * valeur; // affectation 
    valeur = valeur + 1;
    return EXIT_SUCCESS;
}
