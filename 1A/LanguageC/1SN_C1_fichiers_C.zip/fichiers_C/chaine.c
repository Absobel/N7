#include <string.h>
#include <stdio.h>
#include <stdlib.h>

int main(void){
    char mon_nom[] = "Jaffres-Runser"; 
    printf("Longueur de '%s' : %lu caractères\n", mon_nom, strlen(mon_nom));
    printf("Taille du tableau : %lu éléments \n", sizeof(mon_nom));
    printf("dernier élément : '%i' \n", mon_nom[sizeof(mon_nom)-1]);
    return EXIT_SUCCESS;
}
