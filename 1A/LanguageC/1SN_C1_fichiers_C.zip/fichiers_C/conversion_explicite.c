#include <assert.h>
#include <stdio.h>

int main(){
    int quantite = 10; 
    int prix = 15;

    int total = quantite * prix; 
    assert(total == 150);
        
    int nb_personnes_int = 60;
    float prix_par_personne = total /(float) nb_personnes_int;
    assert(prix_par_personne == 2.5); // Maintenant on effectue bien une division réelle 
    
    printf("Le prix par personne est de %1.2f euros", prix_par_personne);
    return 0;
}
