
#include <stdio.h>
#include <stdlib.h>

int main(){
    float cote = 2.0;     //longueur du côté
    char unite = 'm';
    printf("Le périmètre du carré de côté %1.0f%c est : ", cote, unite); 
    //affichage du flottant avec 0 chiffres après la virgule
    
    //calcul et affichage du perimètre
    float perimetre = 4 * cote; 
    printf("%1.2f%c\n", perimetre, unite); 
    //affichage du flottant avec 2 chiffres après la virgule
    
    return EXIT_SUCCESS;
}
