#include <stdlib.h> 
#include <stdio.h>

int main(){
    return EXIT_SUCCESS;
}
