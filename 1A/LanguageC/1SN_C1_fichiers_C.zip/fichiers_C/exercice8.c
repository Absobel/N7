
#include <stdlib.h>
#include <stdio.h>
#include <assert.h>

/**
 * \brief Retourner '<', '>' ou '=' pour indiquer si n est strictement négatif,
 * strictement positif ou nul.
 * \param[in] nombre le nombre dont on veut évaluer le signe
 * \return un caractère donnant le signe d'un nombre
 */
char signe(int nombre)
{
    // TODO: Donner le bon code !
    return '?';
}


////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//                    NE PAS MODIFIER CE QUI SUIT...                          //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

void test_signe() {
    assert('<' == signe(-821));
    assert('<' == signe(-1));
    assert('=' == signe(0));
    assert('>' == signe(125));
    assert('>' == signe(1));
    printf("%s", "signe... ok\n");
}


int main(void) {
    test_signe();
    printf("%s", "Bravo ! Tous les tests passent.\n");
    return EXIT_SUCCESS;
}

