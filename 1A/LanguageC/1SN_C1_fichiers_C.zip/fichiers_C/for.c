
#include <stdlib.h>
#include <stdio.h>
#define LIMITE 30

int main(void) {
    //calcul de la moyenne des LIMITE premiers entiers
    int somme = 0;
    
    // Déclaration du compteur i et initialisation à 1
    // Répétition si i <= LIMITE
    // Incrémentation i = i + 1 à chaque répétition.
    for (int i = 1; i <= LIMITE; i++) {
        somme += i;
    }
    float moyenne = somme / (float) LIMITE; 
    printf("La moyenne des %d premiers entiers est %1.2f\n", LIMITE, moyenne);
    return EXIT_SUCCESS;
}
