#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

int main(){
    int valeur = 10, produit = 23;
    produit += valeur;  // On ajoute valeur à produit
    assert(produit == 33);
    
    produit *= 2; // multiplication par 2 puis affectation
    assert(produit == 66);
    
    produit /= 3; // division par 3 puis affectation
    assert(produit == 22);
    
    valeur++; // incrémentation de valeur
    produit--; // décrémentation de produit
    assert(valeur == 11 && produit == 21);
    
    printf("%s", "Tous les tests passent.\n");
    return EXIT_SUCCESS;
}

