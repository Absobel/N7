int main(){
    int d1 = 1;
    int d2 = 4; 
    int* p_1 ;
    int* p_2 ;
    printf("Avant échange : *p_1 = %d, *p_2 = %d", *p_1, *p_2);
    
    // TODO : echanger les pointeurs
    
    printf("Après échange : *p_1 = %d, *p_2 = %d", *p_1, *p_2);
    return EXIT_SUCCESS;
}
