#include <stdlib.h> 
#include <stdio.h>

int main(){
    printf("******************************\n");
    printf("******** Langage C ***********\n");
    printf("******************************\n");
    return EXIT_SUCCESS;
}
