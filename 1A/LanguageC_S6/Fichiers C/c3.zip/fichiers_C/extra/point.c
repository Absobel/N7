/**
 *  \author KJR <nom@n7.fr>
 *  \file point.c
 *
 *  Objectifs :
 *	Définition d'un module Point.
 *	Un Point est représenté par ses coordonnées géographiques en 
 *	degrés décimaux. 
 */

#include "point.h"
#include <stdlib.h>
#include <stdio.h>

void initialiser_point(Point *p, float longi, float lat){
    // TODO
}

float lire_longitude(Point p){
	// TODO
    return 0;
}

float lire_latitude(Point p){
	// TODO
    return 0;
}

void copier_point(Point *p_dest, Point p_orig){
    p_dest->longitude = p_orig.longitude;
    p_dest->latitude = p_orig.latitude;
}

void point_tostring(char *str, Point p){
    sprintf(str, "( %1.2f, %1.2f )", p.longitude, p.latitude);
}
