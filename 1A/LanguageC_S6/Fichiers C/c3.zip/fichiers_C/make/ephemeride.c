#include "date.h"	//Inclure le module date

int main(){
	Date auj = date_aujourd_hui();
	afficher_date(auj);
}
