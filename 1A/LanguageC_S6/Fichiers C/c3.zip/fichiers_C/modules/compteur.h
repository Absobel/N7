#ifndef _COMPTEUR_H
#define _COMPTEUR_H

// Specification de la procédure re-initialiser
void re_initialiser();
// Specification de la procedure incrementer
void incrementer();
// Specification de la function valeur
int valeur();

#endif 
