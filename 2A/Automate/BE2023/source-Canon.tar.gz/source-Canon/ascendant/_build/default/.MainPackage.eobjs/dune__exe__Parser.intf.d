Parser.mli: Lexing
