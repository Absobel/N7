
module MenhirBasics = struct
  
  exception Error
  
  let _eRR =
    fun _s ->
      raise Error
  
  type token = 
    | UL_VOID
    | UL_SEMI_COLUMN
    | UL_RIGHT_BRACKET
    | UL_RIGHT_BRACE
    | UL_PACKAGE
    | UL_LEFT_BRACKET
    | UL_LEFT_BRACE
    | UL_INTERFACE
    | UL_INT
    | UL_IDENT_PACKAGE of (
# 17 "Parser.mly"
       (string)
# 24 "Parser.ml"
  )
    | UL_IDENT_INTERFACE of (
# 17 "Parser.mly"
       (string)
# 29 "Parser.ml"
  )
    | UL_FIN
    | UL_EXTENDS
    | UL_DOT
    | UL_COMMA
    | UL_BOOLEAN
  
end

include MenhirBasics

# 1 "Parser.mly"
  

(* Partie recopiee dans le fichier CaML genere. *)
(* Ouverture de modules exploites dans les actions *)
(* Declarations de types, de constantes, de fonctions, d'exceptions exploites dans les actions *)


# 49 "Parser.ml"

type ('s, 'r) _menhir_state = 
  | MenhirState00 : ('s, _menhir_box_package) _menhir_state
    (** State 00.
        Stack shape : .
        Start symbol: package. *)

  | MenhirState03 : (('s, _menhir_box_package) _menhir_cell1_UL_PACKAGE _menhir_cell0_UL_IDENT_PACKAGE, _menhir_box_package) _menhir_state
    (** State 03.
        Stack shape : UL_PACKAGE UL_IDENT_PACKAGE.
        Start symbol: package. *)

  | MenhirState06 : (('s, _menhir_box_package) _menhir_cell1_UL_INTERFACE _menhir_cell0_UL_IDENT_INTERFACE, _menhir_box_package) _menhir_state
    (** State 06.
        Stack shape : UL_INTERFACE UL_IDENT_INTERFACE.
        Start symbol: package. *)

  | MenhirState08 : (('s, _menhir_box_package) _menhir_cell1_UL_IDENT_PACKAGE, _menhir_box_package) _menhir_state
    (** State 08.
        Stack shape : UL_IDENT_PACKAGE.
        Start symbol: package. *)

  | MenhirState12 : ((('s, _menhir_box_package) _menhir_cell1_UL_INTERFACE _menhir_cell0_UL_IDENT_INTERFACE, _menhir_box_package) _menhir_cell1_nom_qualifie, _menhir_box_package) _menhir_state
    (** State 12.
        Stack shape : UL_INTERFACE UL_IDENT_INTERFACE nom_qualifie.
        Start symbol: package. *)

  | MenhirState13 : (('s, _menhir_box_package) _menhir_cell1_UL_COMMA, _menhir_box_package) _menhir_state
    (** State 13.
        Stack shape : UL_COMMA.
        Start symbol: package. *)

  | MenhirState17 : (('s, _menhir_box_package) _menhir_cell1_UL_INTERFACE _menhir_cell0_UL_IDENT_INTERFACE _menhir_cell0_maybe_extends, _menhir_box_package) _menhir_state
    (** State 17.
        Stack shape : UL_INTERFACE UL_IDENT_INTERFACE maybe_extends.
        Start symbol: package. *)

  | MenhirState23 : (('s, _menhir_box_package) _menhir_cell1_type_ _menhir_cell0_UL_IDENT_PACKAGE, _menhir_box_package) _menhir_state
    (** State 23.
        Stack shape : type_ UL_IDENT_PACKAGE.
        Start symbol: package. *)

  | MenhirState26 : (('s, _menhir_box_package) _menhir_cell1_type_, _menhir_box_package) _menhir_state
    (** State 26.
        Stack shape : type_.
        Start symbol: package. *)

  | MenhirState35 : (('s, _menhir_box_package) _menhir_cell1_methode, _menhir_box_package) _menhir_state
    (** State 35.
        Stack shape : methode.
        Start symbol: package. *)

  | MenhirState37 : ((('s, _menhir_box_package) _menhir_cell1_UL_PACKAGE _menhir_cell0_UL_IDENT_PACKAGE, _menhir_box_package) _menhir_cell1_package_or_interface, _menhir_box_package) _menhir_state
    (** State 37.
        Stack shape : UL_PACKAGE UL_IDENT_PACKAGE package_or_interface.
        Start symbol: package. *)

  | MenhirState40 : ((('s, _menhir_box_package) _menhir_cell1_package_or_interface, _menhir_box_package) _menhir_cell1_package_or_interface, _menhir_box_package) _menhir_state
    (** State 40.
        Stack shape : package_or_interface package_or_interface.
        Start symbol: package. *)


and 's _menhir_cell0_maybe_extends = 
  | MenhirCell0_maybe_extends of 's * (unit)

and ('s, 'r) _menhir_cell1_methode = 
  | MenhirCell1_methode of 's * ('s, 'r) _menhir_state * (unit)

and ('s, 'r) _menhir_cell1_nom_qualifie = 
  | MenhirCell1_nom_qualifie of 's * ('s, 'r) _menhir_state * (unit)

and ('s, 'r) _menhir_cell1_package_or_interface = 
  | MenhirCell1_package_or_interface of 's * ('s, 'r) _menhir_state * (unit)

and ('s, 'r) _menhir_cell1_type_ = 
  | MenhirCell1_type_ of 's * ('s, 'r) _menhir_state * (unit)

and ('s, 'r) _menhir_cell1_UL_COMMA = 
  | MenhirCell1_UL_COMMA of 's * ('s, 'r) _menhir_state

and 's _menhir_cell0_UL_IDENT_INTERFACE = 
  | MenhirCell0_UL_IDENT_INTERFACE of 's * (
# 17 "Parser.mly"
       (string)
# 135 "Parser.ml"
)

and ('s, 'r) _menhir_cell1_UL_IDENT_PACKAGE = 
  | MenhirCell1_UL_IDENT_PACKAGE of 's * ('s, 'r) _menhir_state * (
# 17 "Parser.mly"
       (string)
# 142 "Parser.ml"
)

and 's _menhir_cell0_UL_IDENT_PACKAGE = 
  | MenhirCell0_UL_IDENT_PACKAGE of 's * (
# 17 "Parser.mly"
       (string)
# 149 "Parser.ml"
)

and ('s, 'r) _menhir_cell1_UL_INTERFACE = 
  | MenhirCell1_UL_INTERFACE of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_UL_PACKAGE = 
  | MenhirCell1_UL_PACKAGE of 's * ('s, 'r) _menhir_state

and _menhir_box_package = 
  | MenhirBox_package of (unit) [@@unboxed]

let _menhir_action_01 =
  fun () ->
    (
# 43 "Parser.mly"
                                                                                                ((print_endline "interface : interface IDENT_INTERFACE maybe_extends { methodes }"))
# 166 "Parser.ml"
     : (unit))

let _menhir_action_02 =
  fun () ->
    (
# 33 "Parser.mly"
                                                                                                                        ( (print_endline "internal_package : package IDENT_PACKAGE { packages_or_interfaces }") )
# 174 "Parser.ml"
     : (unit))

let _menhir_action_03 =
  fun () ->
    (
# 46 "Parser.mly"
                   ((print_endline "maybe_extends : /* Lambda */"))
# 182 "Parser.ml"
     : (unit))

let _menhir_action_04 =
  fun () ->
    (
# 47 "Parser.mly"
                                                  ((print_endline "maybe_extends : extends nom_qualifie other_nom_qualifies"))
# 190 "Parser.ml"
     : (unit))

let _menhir_action_05 =
  fun () ->
    (
# 66 "Parser.mly"
                   ((print_endline "maybe_types : /* Lambda */"))
# 198 "Parser.ml"
     : (unit))

let _menhir_action_06 =
  fun () ->
    (
# 67 "Parser.mly"
            ((print_endline "maybe_types : types"))
# 206 "Parser.ml"
     : (unit))

let _menhir_action_07 =
  fun () ->
    (
# 63 "Parser.mly"
                                                                                             ((print_endline "methode : type IDENT_PACKAGE ( maybe types );"))
# 214 "Parser.ml"
     : (unit))

let _menhir_action_08 =
  fun () ->
    (
# 60 "Parser.mly"
                   ((print_endline "methodes : /* Lambda */"))
# 222 "Parser.ml"
     : (unit))

let _menhir_action_09 =
  fun () ->
    (
# 61 "Parser.mly"
                       ((print_endline "methodes: methode methodes"))
# 230 "Parser.ml"
     : (unit))

let _menhir_action_10 =
  fun () ->
    (
# 49 "Parser.mly"
                                                       ((print_endline "nom_qualifie: point_package_idents IDENT_INTERFACE"))
# 238 "Parser.ml"
     : (unit))

let _menhir_action_11 =
  fun () ->
    (
# 56 "Parser.mly"
                   ((print_endline "other_nom_qualifies : /* Lambda */"))
# 246 "Parser.ml"
     : (unit))

let _menhir_action_12 =
  fun () ->
    (
# 57 "Parser.mly"
                                   ((print_endline "other_nom_qualifies : , other_nom_qualifies"))
# 254 "Parser.ml"
     : (unit))

let _menhir_action_13 =
  fun () ->
    (
# 72 "Parser.mly"
                   ((print_endline "other_types : /* Lambda */"))
# 262 "Parser.ml"
     : (unit))

let _menhir_action_14 =
  fun () ->
    (
# 73 "Parser.mly"
                     ((print_endline "other_types : , other_types"))
# 270 "Parser.ml"
     : (unit))

let _menhir_action_15 =
  fun () ->
    (
# 31 "Parser.mly"
                                  ( (print_endline "package : internal_package FIN") )
# 278 "Parser.ml"
     : (unit))

let _menhir_action_16 =
  fun () ->
    (
# 40 "Parser.mly"
                       ((print_endline "package_or_interface : internal_package"))
# 286 "Parser.ml"
     : (unit))

let _menhir_action_17 =
  fun () ->
    (
# 41 "Parser.mly"
                ((print_endline "package_or_interface : interface"))
# 294 "Parser.ml"
     : (unit))

let _menhir_action_18 =
  fun () ->
    (
# 36 "Parser.mly"
                   ((print_endline "packages_or_interfaces : "))
# 302 "Parser.ml"
     : (unit))

let _menhir_action_19 =
  fun () ->
    (
# 37 "Parser.mly"
                                                  ((print_endline "packages_or_interfaces : package_or_interface packages_or_interfaces"))
# 310 "Parser.ml"
     : (unit))

let _menhir_action_20 =
  fun () ->
    (
# 52 "Parser.mly"
                   ((print_endline "point_package_idents : /* Lambda */"))
# 318 "Parser.ml"
     : (unit))

let _menhir_action_21 =
  fun () ->
    (
# 53 "Parser.mly"
                                                   ((print_endline "point_package_idents : IDENT_PACKAGE.point_package_idents"))
# 326 "Parser.ml"
     : (unit))

let _menhir_action_22 =
  fun () ->
    (
# 76 "Parser.mly"
                 ((print_endline "type : boolean"))
# 334 "Parser.ml"
     : (unit))

let _menhir_action_23 =
  fun () ->
    (
# 77 "Parser.mly"
             ((print_endline "type : int"))
# 342 "Parser.ml"
     : (unit))

let _menhir_action_24 =
  fun () ->
    (
# 78 "Parser.mly"
              ((print_endline "type : void"))
# 350 "Parser.ml"
     : (unit))

let _menhir_action_25 =
  fun () ->
    (
# 79 "Parser.mly"
                   ((print_endline "type : nom_qualifie"))
# 358 "Parser.ml"
     : (unit))

let _menhir_action_26 =
  fun () ->
    (
# 69 "Parser.mly"
                          ((print_endline "types: type other_types"))
# 366 "Parser.ml"
     : (unit))

let _menhir_print_token : token -> string =
  fun _tok ->
    match _tok with
    | UL_BOOLEAN ->
        "UL_BOOLEAN"
    | UL_COMMA ->
        "UL_COMMA"
    | UL_DOT ->
        "UL_DOT"
    | UL_EXTENDS ->
        "UL_EXTENDS"
    | UL_FIN ->
        "UL_FIN"
    | UL_IDENT_INTERFACE _ ->
        "UL_IDENT_INTERFACE"
    | UL_IDENT_PACKAGE _ ->
        "UL_IDENT_PACKAGE"
    | UL_INT ->
        "UL_INT"
    | UL_INTERFACE ->
        "UL_INTERFACE"
    | UL_LEFT_BRACE ->
        "UL_LEFT_BRACE"
    | UL_LEFT_BRACKET ->
        "UL_LEFT_BRACKET"
    | UL_PACKAGE ->
        "UL_PACKAGE"
    | UL_RIGHT_BRACE ->
        "UL_RIGHT_BRACE"
    | UL_RIGHT_BRACKET ->
        "UL_RIGHT_BRACKET"
    | UL_SEMI_COLUMN ->
        "UL_SEMI_COLUMN"
    | UL_VOID ->
        "UL_VOID"

let _menhir_fail : unit -> 'a =
  fun () ->
    Printf.eprintf "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

include struct
  
  [@@@ocaml.warning "-4-37"]
  
  let _menhir_run_45 : type  ttv_stack. ttv_stack -> _ -> _menhir_box_package =
    fun _menhir_stack _tok ->
      match (_tok : MenhirBasics.token) with
      | UL_FIN ->
          let _v = _menhir_action_15 () in
          MenhirBox_package _v
      | _ ->
          _eRR ()
  
  let rec _menhir_run_01 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_UL_PACKAGE (_menhir_stack, _menhir_s) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_IDENT_PACKAGE _v ->
          let _menhir_stack = MenhirCell0_UL_IDENT_PACKAGE (_menhir_stack, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UL_LEFT_BRACE ->
              let _menhir_s = MenhirState03 in
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | UL_PACKAGE ->
                  _menhir_run_01 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
              | UL_INTERFACE ->
                  _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_04 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_UL_INTERFACE (_menhir_stack, _menhir_s) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_IDENT_INTERFACE _v ->
          let _menhir_stack = MenhirCell0_UL_IDENT_INTERFACE (_menhir_stack, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UL_EXTENDS ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | UL_IDENT_PACKAGE _v_0 ->
                  _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState06
              | UL_IDENT_INTERFACE _ ->
                  let _ = _menhir_action_20 () in
                  _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState06 _tok
              | _ ->
                  _eRR ())
          | UL_LEFT_BRACE ->
              let _v = _menhir_action_03 () in
              _menhir_goto_maybe_extends _menhir_stack _menhir_lexbuf _menhir_lexer _v
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_07 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _menhir_stack = MenhirCell1_UL_IDENT_PACKAGE (_menhir_stack, _menhir_s, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_DOT ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UL_IDENT_PACKAGE _v_0 ->
              _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState08
          | UL_IDENT_INTERFACE _ ->
              let _ = _menhir_action_20 () in
              _menhir_run_09 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_09 : type  ttv_stack. (ttv_stack, _menhir_box_package) _menhir_cell1_UL_IDENT_PACKAGE -> _ -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _tok ->
      let MenhirCell1_UL_IDENT_PACKAGE (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _ = _menhir_action_21 () in
      _menhir_goto_point_package_idents _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
  
  and _menhir_goto_point_package_idents : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok ->
      match _menhir_s with
      | MenhirState35 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState17 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState23 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState26 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState06 ->
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState08 ->
          _menhir_run_09 _menhir_stack _menhir_lexbuf _menhir_lexer _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_10 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | UL_IDENT_INTERFACE _ ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let _v = _menhir_action_10 () in
          _menhir_goto_nom_qualifie _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_goto_nom_qualifie : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState35 ->
          _menhir_run_28 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState17 ->
          _menhir_run_28 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState23 ->
          _menhir_run_28 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState26 ->
          _menhir_run_28 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState06 ->
          _menhir_run_12 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_28 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok ->
      let _v = _menhir_action_25 () in
      _menhir_goto_type_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_type_ : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState26 ->
          _menhir_run_25 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState23 ->
          _menhir_run_25 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState35 ->
          _menhir_run_21 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState17 ->
          _menhir_run_21 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_25 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_type_ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_COMMA ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UL_VOID ->
              _menhir_run_18 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState26
          | UL_INT ->
              _menhir_run_19 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState26
          | UL_IDENT_PACKAGE _v_0 ->
              _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState26
          | UL_BOOLEAN ->
              _menhir_run_20 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState26
          | UL_IDENT_INTERFACE _ ->
              let _ = _menhir_action_20 () in
              _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState26 _tok
          | _ ->
              _eRR ())
      | UL_RIGHT_BRACKET ->
          let _ = _menhir_action_13 () in
          _menhir_goto_other_types _menhir_stack _menhir_lexbuf _menhir_lexer
      | _ ->
          _eRR ()
  
  and _menhir_run_18 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let _v = _menhir_action_24 () in
      _menhir_goto_type_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_19 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let _v = _menhir_action_23 () in
      _menhir_goto_type_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_20 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let _v = _menhir_action_22 () in
      _menhir_goto_type_ _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_other_types : type  ttv_stack. (ttv_stack, _menhir_box_package) _menhir_cell1_type_ -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let MenhirCell1_type_ (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _ = _menhir_action_26 () in
      _menhir_goto_types _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
  
  and _menhir_goto_types : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      match _menhir_s with
      | MenhirState26 ->
          _menhir_run_27 _menhir_stack _menhir_lexbuf _menhir_lexer
      | MenhirState23 ->
          _menhir_run_24 _menhir_stack _menhir_lexbuf _menhir_lexer
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_27 : type  ttv_stack. (ttv_stack, _menhir_box_package) _menhir_cell1_type_ -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _ = _menhir_action_14 () in
      _menhir_goto_other_types _menhir_stack _menhir_lexbuf _menhir_lexer
  
  and _menhir_run_24 : type  ttv_stack. (ttv_stack, _menhir_box_package) _menhir_cell1_type_ _menhir_cell0_UL_IDENT_PACKAGE -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _ = _menhir_action_06 () in
      _menhir_goto_maybe_types _menhir_stack _menhir_lexbuf _menhir_lexer
  
  and _menhir_goto_maybe_types : type  ttv_stack. (ttv_stack, _menhir_box_package) _menhir_cell1_type_ _menhir_cell0_UL_IDENT_PACKAGE -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_SEMI_COLUMN ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell0_UL_IDENT_PACKAGE (_menhir_stack, _) = _menhir_stack in
          let MenhirCell1_type_ (_menhir_stack, _menhir_s, _) = _menhir_stack in
          let _v = _menhir_action_07 () in
          let _menhir_stack = MenhirCell1_methode (_menhir_stack, _menhir_s, _v) in
          (match (_tok : MenhirBasics.token) with
          | UL_VOID ->
              _menhir_run_18 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState35
          | UL_INT ->
              _menhir_run_19 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState35
          | UL_IDENT_PACKAGE _v_0 ->
              _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState35
          | UL_BOOLEAN ->
              _menhir_run_20 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState35
          | UL_RIGHT_BRACE ->
              let _ = _menhir_action_08 () in
              _menhir_run_36 _menhir_stack _menhir_lexbuf _menhir_lexer
          | UL_IDENT_INTERFACE _ ->
              let _ = _menhir_action_20 () in
              _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState35 _tok
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_36 : type  ttv_stack. (ttv_stack, _menhir_box_package) _menhir_cell1_methode -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let MenhirCell1_methode (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _ = _menhir_action_09 () in
      _menhir_goto_methodes _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
  
  and _menhir_goto_methodes : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      match _menhir_s with
      | MenhirState35 ->
          _menhir_run_36 _menhir_stack _menhir_lexbuf _menhir_lexer
      | MenhirState17 ->
          _menhir_run_33 _menhir_stack _menhir_lexbuf _menhir_lexer
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_33 : type  ttv_stack. (ttv_stack, _menhir_box_package) _menhir_cell1_UL_INTERFACE _menhir_cell0_UL_IDENT_INTERFACE _menhir_cell0_maybe_extends -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let MenhirCell0_maybe_extends (_menhir_stack, _) = _menhir_stack in
      let MenhirCell0_UL_IDENT_INTERFACE (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_UL_INTERFACE (_menhir_stack, _menhir_s) = _menhir_stack in
      let _ = _menhir_action_01 () in
      let _v = _menhir_action_17 () in
      _menhir_goto_package_or_interface _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_package_or_interface : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState40 ->
          _menhir_run_40 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState37 ->
          _menhir_run_40 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState03 ->
          _menhir_run_37 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_40 : type  ttv_stack. ((ttv_stack, _menhir_box_package) _menhir_cell1_package_or_interface as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_package_or_interface (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_PACKAGE ->
          _menhir_run_01 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState40
      | UL_INTERFACE ->
          _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState40
      | UL_RIGHT_BRACE ->
          let _ = _menhir_action_18 () in
          _menhir_run_41 _menhir_stack _menhir_lexbuf _menhir_lexer
      | _ ->
          _eRR ()
  
  and _menhir_run_41 : type  ttv_stack. ((ttv_stack, _menhir_box_package) _menhir_cell1_package_or_interface, _menhir_box_package) _menhir_cell1_package_or_interface -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let MenhirCell1_package_or_interface (_menhir_stack, _menhir_s, _) = _menhir_stack in
      let _ = _menhir_action_19 () in
      _menhir_goto_packages_or_interfaces _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
  
  and _menhir_goto_packages_or_interfaces : type  ttv_stack. ((ttv_stack, _menhir_box_package) _menhir_cell1_package_or_interface as 'stack) -> _ -> _ -> ('stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      match _menhir_s with
      | MenhirState40 ->
          _menhir_run_41 _menhir_stack _menhir_lexbuf _menhir_lexer
      | MenhirState37 ->
          _menhir_run_38 _menhir_stack _menhir_lexbuf _menhir_lexer
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_38 : type  ttv_stack. ((ttv_stack, _menhir_box_package) _menhir_cell1_UL_PACKAGE _menhir_cell0_UL_IDENT_PACKAGE, _menhir_box_package) _menhir_cell1_package_or_interface -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let MenhirCell1_package_or_interface (_menhir_stack, _, _) = _menhir_stack in
      let MenhirCell0_UL_IDENT_PACKAGE (_menhir_stack, _) = _menhir_stack in
      let MenhirCell1_UL_PACKAGE (_menhir_stack, _menhir_s) = _menhir_stack in
      let _ = _menhir_action_02 () in
      _menhir_goto_internal_package _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
  
  and _menhir_goto_internal_package : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok ->
      match _menhir_s with
      | MenhirState00 ->
          _menhir_run_45 _menhir_stack _tok
      | MenhirState03 ->
          _menhir_run_42 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState37 ->
          _menhir_run_42 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | MenhirState40 ->
          _menhir_run_42 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_42 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s _tok ->
      let _v = _menhir_action_16 () in
      _menhir_goto_package_or_interface _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_37 : type  ttv_stack. ((ttv_stack, _menhir_box_package) _menhir_cell1_UL_PACKAGE _menhir_cell0_UL_IDENT_PACKAGE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_package_or_interface (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_PACKAGE ->
          _menhir_run_01 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState37
      | UL_INTERFACE ->
          _menhir_run_04 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState37
      | UL_RIGHT_BRACE ->
          let _ = _menhir_action_18 () in
          _menhir_run_38 _menhir_stack _menhir_lexbuf _menhir_lexer
      | _ ->
          _eRR ()
  
  and _menhir_run_21 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_type_ (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_IDENT_PACKAGE _v_0 ->
          let _menhir_stack = MenhirCell0_UL_IDENT_PACKAGE (_menhir_stack, _v_0) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | UL_LEFT_BRACKET ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | UL_VOID ->
                  _menhir_run_18 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState23
              | UL_INT ->
                  _menhir_run_19 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState23
              | UL_IDENT_PACKAGE _v_1 ->
                  _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _v_1 MenhirState23
              | UL_BOOLEAN ->
                  _menhir_run_20 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState23
              | UL_RIGHT_BRACKET ->
                  let _ = _menhir_action_05 () in
                  _menhir_goto_maybe_types _menhir_stack _menhir_lexbuf _menhir_lexer
              | UL_IDENT_INTERFACE _ ->
                  let _ = _menhir_action_20 () in
                  _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState23 _tok
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_run_12 : type  ttv_stack. ((ttv_stack, _menhir_box_package) _menhir_cell1_UL_INTERFACE _menhir_cell0_UL_IDENT_INTERFACE as 'stack) -> _ -> _ -> _ -> ('stack, _menhir_box_package) _menhir_state -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let _menhir_stack = MenhirCell1_nom_qualifie (_menhir_stack, _menhir_s, _v) in
      match (_tok : MenhirBasics.token) with
      | UL_COMMA ->
          _menhir_run_13 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState12
      | UL_LEFT_BRACE ->
          let _ = _menhir_action_11 () in
          _menhir_run_15 _menhir_stack _menhir_lexbuf _menhir_lexer
      | _ ->
          _eRR ()
  
  and _menhir_run_13 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_UL_COMMA (_menhir_stack, _menhir_s) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_COMMA ->
          _menhir_run_13 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState13
      | UL_LEFT_BRACE ->
          let _ = _menhir_action_11 () in
          _menhir_run_14 _menhir_stack _menhir_lexbuf _menhir_lexer
      | _ ->
          _eRR ()
  
  and _menhir_run_14 : type  ttv_stack. (ttv_stack, _menhir_box_package) _menhir_cell1_UL_COMMA -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let MenhirCell1_UL_COMMA (_menhir_stack, _menhir_s) = _menhir_stack in
      let _ = _menhir_action_12 () in
      _menhir_goto_other_nom_qualifies _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
  
  and _menhir_goto_other_nom_qualifies : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_package) _menhir_state -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      match _menhir_s with
      | MenhirState12 ->
          _menhir_run_15 _menhir_stack _menhir_lexbuf _menhir_lexer
      | MenhirState13 ->
          _menhir_run_14 _menhir_stack _menhir_lexbuf _menhir_lexer
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_15 : type  ttv_stack. ((ttv_stack, _menhir_box_package) _menhir_cell1_UL_INTERFACE _menhir_cell0_UL_IDENT_INTERFACE, _menhir_box_package) _menhir_cell1_nom_qualifie -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let MenhirCell1_nom_qualifie (_menhir_stack, _, _) = _menhir_stack in
      let _v = _menhir_action_04 () in
      _menhir_goto_maybe_extends _menhir_stack _menhir_lexbuf _menhir_lexer _v
  
  and _menhir_goto_maybe_extends : type  ttv_stack. (ttv_stack, _menhir_box_package) _menhir_cell1_UL_INTERFACE _menhir_cell0_UL_IDENT_INTERFACE -> _ -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v ->
      let _menhir_stack = MenhirCell0_maybe_extends (_menhir_stack, _v) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_VOID ->
          _menhir_run_18 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState17
      | UL_INT ->
          _menhir_run_19 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState17
      | UL_IDENT_PACKAGE _v_0 ->
          _menhir_run_07 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState17
      | UL_BOOLEAN ->
          _menhir_run_20 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState17
      | UL_RIGHT_BRACE ->
          let _ = _menhir_action_08 () in
          _menhir_run_33 _menhir_stack _menhir_lexbuf _menhir_lexer
      | UL_IDENT_INTERFACE _ ->
          let _ = _menhir_action_20 () in
          _menhir_run_10 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState17 _tok
      | _ ->
          _eRR ()
  
  let _menhir_run_00 : type  ttv_stack. ttv_stack -> _ -> _ -> _menhir_box_package =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _menhir_s = MenhirState00 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | UL_PACKAGE ->
          _menhir_run_01 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
end

let package =
  fun _menhir_lexer _menhir_lexbuf ->
    let _menhir_stack = () in
    let MenhirBox_package v = _menhir_run_00 _menhir_stack _menhir_lexbuf _menhir_lexer in
    v

# 80 "Parser.mly"
  


# 894 "Parser.ml"
