Scanner.ml: Lexing Tokens
